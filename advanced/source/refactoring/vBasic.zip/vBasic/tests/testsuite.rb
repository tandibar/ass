require 'test/unit'
require "movie_test"
require "rental_test"
require "customer_test"