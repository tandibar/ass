require 'test/unit'
require "#{File.dirname(__FILE__)}/../movie"
require "#{File.dirname(__FILE__)}/../rental"
require "#{File.dirname(__FILE__)}/../customer"